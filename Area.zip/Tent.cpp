#include "Tent.h"
#include <iostream>

Tent::Tent() : weatherProtectionActive(false) {}
bool Tent::isWeatherProtected() const { 
    return weatherProtectionActive; 
}

void Tent::weatherAlert(int severity, const std::string& type){
    weatherProtectionActive = true;
    std::cout << "Tent: activating weather protection" << std::endl;
    this->setWeatherData(severity, type);
    this->Subject::weatherAlert();
}

void Tent::escapedBull(const std::string& location, int numBulls) {
    std::cout << "Tent: Securing tent - Bull escape at " << location << "!" << std::endl;

    this->setBullEscape(location, numBulls);
    this->Subject::escapedBull();
}

void Tent::medicalEmergency(int severity, const std::string& injuryType){
    std::cout << "Tent: Clearing paths - Medical emergency! (" << injuryType << ")" << std::endl;
    
    this->setMedicalEmergency(severity, injuryType);
    this->Subject::medicalEmergency();
}

void Tent::capacityAlert(int currentCount, int maxCapacity){
    std::cout << "Tent: Monitoring capacity - " << currentCount << "/" << maxCapacity << std::endl;
    
    this->setCapacityAlert(currentCount, maxCapacity);
    this->Subject::capacityAlert();
}

void Tent::setup(){
    std::cout << "Tent: Opening" << std::endl;
    this->open();
    this->Subject::setup();
}

void Tent::shutdown(){
    std::cout << "Tent: Closing" << std::endl;
    this->close();
    this->Subject::shutdown();
}



