#include "MedicalArea.h"
#include <iostream>

MedicalArea::MedicalArea() : emergencyProtocolActive(false) {}

void MedicalArea::open(){
    Composite::open();
}

void MedicalArea::close(){
    Composite::close();
}

void MedicalArea::reportStatus() const{
    Composite::reportStatus();
}

void MedicalArea::getCapacity() const{
    Composite::getCapacity();
}

void MedicalArea::weatherAlert(int severity, const std::string& type){
    std::cout << "Medical Area: Remaining Open - " << type << "! [Severity " << severity << "/" << Subject::MaxSeverity << std::endl;
    this->setWeatherData(severity, type);
    this->Subject::weatherAlert();
}

void MedicalArea::escapedBull(const std::string& location, int numBulls){
    preparedForInjuries = true;
    std::cout << "MedicalArea: preparing for injuries" << std::endl;
    this->setBullEscape(location, numBulls);
    this->Subject::escapedBull();
}

void MedicalArea::medicalEmergency(int severity, const std::string& injuryType){
    std::cout << "MedicalArea: Activating emergency protocols! (" << injuryType << ", severity " << severity << ")" << std::endl;
    this->emergencyProtocolActive = true;

    std::cout << "All medical teams mobilized" << std::endl;
    
    this->setMedicalEmergency(severity, injuryType);
    this->Subject::medicalEmergency();
}


void MedicalArea::capacityAlert(int currentCount, int maxCapacity){
    bedsPrepared = true;
    std::cout << "MedicalArea: preparing extra beds" << std::endl;
    this->setCapacityAlert(currentCount, maxCapacity);
    this->Subject::capacityAlert();
}

void MedicalArea::setup(){
    std::cout << "MedicalArea: Activating emergency protocols" << std::endl;
    this->emergencyProtocolActive = true;
    this->open();
    this->Subject::setup();
}

void MedicalArea::shutdown(){
    std::cout << "MedicalArea: Closing" << std::endl;
    this->emergencyProtocolActive = false;
    this->close();
    this->Subject::shutdown();
}