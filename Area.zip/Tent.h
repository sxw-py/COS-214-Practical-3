#ifndef TENT_H
#define TENT_H

#include "Composite.h"
#include "Area.h"

class Tent : public Composite
{
    private:
        bool weatherProtectionActive;
    public:
        Tent();
        bool isWeatherProtected() const;
        virtual void weatherAlert(int severity, const std::string& type) override;
        virtual void escapedBull(const std::string& location, int numBulls) override;
        virtual void medicalEmergency(int severity, const std::string& injuryType) override;
        virtual void capacityAlert(int currentCount, int maxCapacity) override;
        virtual void setup() override;
        virtual void shutdown() override;
};

#endif
