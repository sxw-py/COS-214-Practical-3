#include "DrinkStall.h"
#include <iostream>

DrinkStall::DrinkStall() : drinksSecured(false) {}

int DrinkStall::unitCost() const
{
	return 10;
}

void DrinkStall::weatherAlert(int severity, const std::string& type){
	std::cout << "Drinks stall : Closing - " << type << "(severity" << severity << "/" << Subject::MaxSeverity << ")" << std::endl;

	this ->drinksSecured = true;
	this->close();
}


void DrinkStall::escapedBull(const std::string& location, int numBulls){
	std::cout << "Drinks stall : Closing - Bull escape at " << location << "!" << std::endl;
	std::cout << "- Staff moved to safety"<< std::endl;
	std::cout << "- Food secured" << std::endl;

	this ->drinksSecured = true;
	this->close();
}

void DrinkStall::medicalEmergency(int severity, const std::string& injuryType){
    std::cout << "Drinks Stall: Pausing - Medical emergency! ("  << injuryType << ")" << std::endl;
    this->close();
}

void DrinkStall::capacityAlert(int currentCount, int maxCapacity){
    std::cout << " Drinks Stall: Monitoring capacity - " << currentCount << "/" << maxCapacity << std::endl;
}

void DrinkStall::setup(){
    std::cout << "Drinks Stall: Opening" << std::endl;
    this->drinksSecured = false;
    this->open();
}

void DrinkStall::shutdown(){
    std::cout << " Drinks Stall: Closing" << std::endl;
    this->drinksSecured = true;
    this->close();
}
